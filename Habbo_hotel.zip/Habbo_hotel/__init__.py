# habbo_hotel/__init__.py
from . import models

