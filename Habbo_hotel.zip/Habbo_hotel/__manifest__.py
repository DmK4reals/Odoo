{
    'name': 'Habbo Hotel',
    'version': '1.0',
    'summary': 'Gestion complète d\'hôtel ',
    'description': """
        Module de gestion d'hôtel comprenant la gestion des bâtiments, des chambres,
        des commodités, des clients, des réservations, des paiements, des factures,
        des espaces, du personnel et du planning.
    """,
    'category': 'Hotel Management',
    'author': 'DmK',
    'website': 'http://www.example.com',
    'depends': ['base', 'account'],
    'data': [
        'security/ir.model.access.csv',
        'views/hotel_building_view.xml',
        'views/hotel_room_views.xml',
        'views/hotel_amenity_views.xml',
        'views/hotel_client_views.xml',
        'views/hotel_reservation_views.xml',
        'views/hotel_payment_views.xml',
        'views/hotel_invoice_views.xml',
        'views/hotel_space_views.xml',
        'views/hotel_staff_views.xml',
        'views/hotel_schedule_views.xml',
        'data/hotel_schedule_data.xml',
        'static/src/css/custom_style.css'
    ],
    'installable': True,
    'application': True,
}
