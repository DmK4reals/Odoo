from odoo import models, fields

class HotelInvoice(models.Model):
    _name = 'hotel.invoice'
    _description = 'Hotel Invoice'

    reservation_id = fields.Many2one('hotel.reservation', string='Reservation', required=True)
    amount = fields.Float(string='Amount', required=True)
    invoice_date = fields.Datetime(string='Invoice Date', default=fields.Datetime.now, required=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('sent', 'Sent'),
        ('paid', 'Paid')
    ], string='Status', readonly=True, default='draft')
