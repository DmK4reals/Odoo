from odoo import models, fields, api

class HotelReservation(models.Model):
    _name = 'hotel.reservation'
    _description = 'Hotel Reservation'

    name = fields.Char(string='Reservation Reference', required=True, copy=False, readonly=True, index=True, default=lambda self: ('New'))
    client_id = fields.Many2one('hotel.client', string='Client', required=True)
    room_id = fields.Many2one('hotel.room', string='Room', required=True)
    check_in = fields.Datetime(string='Check-in Date', required=True)
    check_out = fields.Datetime(string='Check-out Date', required=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed'),
        ('cancelled', 'Cancelled')
    ], string='Status', readonly=True, default='draft')

    @api.model
    
    def create(self, vals):
        if vals.get('name', ('New')) == ('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('hotel.reservation') or ('New')
        result = super(HotelReservation, self).create(vals)
        return result
    def get_available_rooms(self, check_in, check_out):
     reserved_room_ids = self.env['hotel.reservation'].search([
        ('check_in', '<=', check_out),
        ('check_out', '>=', check_in)
      ]).mapped('room_id.id')
    
     available_rooms = self.env['hotel.room'].search([('id', 'not in', reserved_room_ids)])
     return available_rooms
    def get_reservations(self, start_date, end_date):
        reservations = self.search([('check_in', '>=', start_date), ('check_out', '<=', end_date)])
        reservations.read(['client_id', 'room_id'])
        return reservations


    @api.constrains('check_in', 'check_out')
    def _check_dates(self):
        for record in self:
            if record.check_in >= record.check_out:
                raise models.ValidationError('Check-out date must be after check-in date')
