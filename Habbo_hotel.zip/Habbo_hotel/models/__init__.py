# habbo_hotel/models/__init__.py
from . import hotel_building
from . import hotel_room
from . import hotel_amenity
from . import hotel_client
from . import hotel_reservation
from . import hotel_payment
from . import hotel_invoice
from . import hotel_space
from . import hotel_staff
from . import hotel_schedule