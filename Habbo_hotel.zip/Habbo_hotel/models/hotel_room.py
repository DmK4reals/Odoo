from odoo import models, fields, api

class HotelRoom(models.Model):
    _name = 'hotel.room'
    _description = 'Hotel Room'

    name = fields.Char(string='Room Name', required=True)
    capacity = fields.Integer(string='Capacity', default=1)
    category_id = fields.Many2one('hotel.room.category', string='Category')
    is_available = fields.Boolean(string='Is Available', default=True)

    @api.model
    def search_rooms(self, capacity, category_id=False, sort_by='name'):
        domain = [('capacity', '>=', capacity)]
        
        if category_id:
            domain.append(('category_id', '=', category_id))
        # Exemple d'utilisation


        hotel_habbo = self.env['hotel.hotel'].create({'name': 'Habbo Hotel'})
        room_101 = self.env['hotel.room'].create({'name': 'Room 101', 'hotel_id': hotel_habbo.id})

        self.env['hotel.schedule'].create({
            'name': 'Morning Shift',
            'hotel_id': hotel_habbo.id,
            'room_id': room_101.id,
        })
