from odoo import models, fields

class HotelBuilding(models.Model):
    _name = 'hotel.building'
    _description = 'Hotel Building'

    name = fields.Char(string='Name', required=True)
    address = fields.Char(string='Address', required=True)
    description = fields.Text(string='Description')
    number_of_rooms = fields.Integer(string='Number of Rooms', required=True)  # Nouveau champ
