from odoo import models, fields

class HotelSchedule(models.Model):
    _name = 'hotel.schedule'
    _description = 'Hotel Schedule'

    name = fields.Char(string='Name', required=True)
    hotel_id = fields.Many2one('hotel.hotel', string='Hotel', required=True)
    room_id = fields.Many2one('hotel.room', string='Room', required=True)
    start_date = fields.Datetime(string='Start Date', required=True)
    end_date = fields.Datetime(string='End Date')
