from odoo import models, fields

class HotelSpace(models.Model):
    _name = 'hotel.space'
    _description = 'Hotel Space'

    name = fields.Char(string='Name', required=True)
    capacity = fields.Integer(string='Capacity', required=True)
    description = fields.Text(string='Description')
