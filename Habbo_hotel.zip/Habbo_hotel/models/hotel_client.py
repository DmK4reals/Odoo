from odoo import models, fields

class HotelClient(models.Model):
    _name = 'hotel.client'
    _description = 'Hotel Client'

    name = fields.Char(string='Name', required=True)
    email = fields.Char(string='Email', required=True)
    phone = fields.Char(string='Phone')
    address = fields.Char(string='Address')
