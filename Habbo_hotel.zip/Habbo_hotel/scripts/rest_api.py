import requests

url = 'http://DmK:8069'
db = 'odoo-15'
username = 'DmK'
password = '****'
headers = {
    'Content-Type': 'application/json',
}

# Authentication
response = requests.post(
    f'{url}/web/session/authenticate',
    json={
        'jsonrpc': '2.0',
        'params': {
            'odoo-15': db,
            'DmK': username,
            '****': password,
        },
    },
    headers=headers
)
session_id = response.json()['result']['session_id']

# Batching request
response = requests.post(
    f'{url}/web/dataset/call_kw/hotel.reservation/search_read',
    json={
        'jsonrpc': '2.0',
        'method': 'call',
        'params': {
            'args': [[]],
            'kwargs': {
                'fields': ['name', 'client_id', 'room_id', 'check_in', 'check_out', 'state'],
                'limit': 80,
            },
        },
    },
    headers={
        'Content-Type': 'application/json',
        'X-Openerp-Session-Id': session_id,
    }
)

reservations = response.json()['result']
for reservation in reservations:
    print(reservation)
