import xmlrpc.client

url = 'http://DmK:8069'
db = 'odoo-15'
username = 'DmK'
password = '****'

common = xmlrpc.client.ServerProxy('{}/xmlrpc/2/common'.format(url))
uid = common.authenticate(db, username, password, {})
models = xmlrpc.client.ServerProxy('{}/xmlrpc/2/object'.format(url))

# Récupération des réservations en batch
reservation_ids = models.execute_kw(db, uid, password, 'hotel.reservation', 'search', [[]])
reservations = models.execute_kw(db, uid, password, 'hotel.reservation', 'read', [reservation_ids, ['name', 'client_id', 'room_id', 'check_in', 'check_out', 'state']])

for reservation in reservations:
    print(reservation)
